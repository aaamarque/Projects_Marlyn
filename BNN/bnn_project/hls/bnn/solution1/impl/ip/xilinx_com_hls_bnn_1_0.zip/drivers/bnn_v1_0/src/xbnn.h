// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XBNN_H
#define XBNN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xbnn_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XBnn_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XBnn;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBnn_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBnn_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBnn_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBnn_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XBnn_Initialize(XBnn *InstancePtr, UINTPTR BaseAddress);
XBnn_Config* XBnn_LookupConfig(UINTPTR BaseAddress);
#else
int XBnn_Initialize(XBnn *InstancePtr, u16 DeviceId);
XBnn_Config* XBnn_LookupConfig(u16 DeviceId);
#endif
int XBnn_CfgInitialize(XBnn *InstancePtr, XBnn_Config *ConfigPtr);
#else
int XBnn_Initialize(XBnn *InstancePtr, const char* InstanceName);
int XBnn_Release(XBnn *InstancePtr);
#endif

void XBnn_Start(XBnn *InstancePtr);
u32 XBnn_IsDone(XBnn *InstancePtr);
u32 XBnn_IsIdle(XBnn *InstancePtr);
u32 XBnn_IsReady(XBnn *InstancePtr);
void XBnn_EnableAutoRestart(XBnn *InstancePtr);
void XBnn_DisableAutoRestart(XBnn *InstancePtr);

void XBnn_Set_IN_r(XBnn *InstancePtr, u64 Data);
u64 XBnn_Get_IN_r(XBnn *InstancePtr);
void XBnn_Set_ys(XBnn *InstancePtr, u64 Data);
u64 XBnn_Get_ys(XBnn *InstancePtr);

void XBnn_InterruptGlobalEnable(XBnn *InstancePtr);
void XBnn_InterruptGlobalDisable(XBnn *InstancePtr);
void XBnn_InterruptEnable(XBnn *InstancePtr, u32 Mask);
void XBnn_InterruptDisable(XBnn *InstancePtr, u32 Mask);
void XBnn_InterruptClear(XBnn *InstancePtr, u32 Mask);
u32 XBnn_InterruptGetEnabled(XBnn *InstancePtr);
u32 XBnn_InterruptGetStatus(XBnn *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
